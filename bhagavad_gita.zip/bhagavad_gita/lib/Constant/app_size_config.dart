var height;
var width;
const kDefaultPadding = 20.0;
const kDefaultCornerRadius = 8.0;
const kPadding = 10.0;
