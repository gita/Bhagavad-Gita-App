import 'package:bhagavad_gita/models/tanslation_response_model.dart';

TranslationResponseModel savedVerseTranslation = TranslationResponseModel(
  authorName: 'Swami Adidevananda',
  language: 'english',
  title: 'English translation by Swami Adidevananda',
);

TranslationResponseModel savedVerseCommentary = TranslationResponseModel(
  authorName: 'Swami Sivananda',
  language: 'english',
  title: 'English Commentary by Swami Sivananda',
);