const String strGitaHttpLink = "https://bhagavadgita.graphcdn.app/";
